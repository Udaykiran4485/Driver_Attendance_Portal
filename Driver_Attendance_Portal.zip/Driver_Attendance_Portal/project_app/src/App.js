import logo from './logo.svg';
import './App.css';

import {BrowserRouter,Routes,Route} from 'react-router-dom';
import Dash from './Componenets/Dashboard';
import Month from './Componenets/MonthlyReport';
import Driver from './Componenets/DriversInfo';
import Cleaner from './Componenets/CleanersInfo';
// import Drivers from './Componenets/DriversCurrentMonthReport';
import Cleaners from './Componenets/CleanersCurrentMonthReport';
import Daily from './Componenets/DailyAttendanceReport';
import Form from './Componenets/Form';
import 'bootstrap/dist/css/bootstrap.css';
import Login from './Componenets/Login';
// import Footer from './Componenets/Footer';
import About from './Componenets/about (2)';
import Link from './Componenets/link';


function App() {
  return (
    <div>
      <>
    <BrowserRouter>
    
    <Routes>
    <Route path ="/"  element ={<Login/>}/>
    <Route path ="/dash"  element ={<Dash/>}/>
    <Route path ="/drinfo"  element ={<Driver/>}/>
    <Route path ="/crinfo"  element ={<Cleaner/>}/>
    <Route path ="/dar"  element ={<Daily/>}/>
    {/* <Route path ="/dcmr"  element ={<Drivers/>}/> */}
    <Route path ="/ccmr"  element ={<Cleaners/>}/>
    <Route path ="/mr"  element ={<Month/>}/>
    <Route path ="/form"  element ={<Form/>}/>



    </Routes>

    </BrowserRouter>
    </>
    // <About/>
    // </div>
//     <div>
// <Link/>
//     </div>
    
  );
}

export default App;
