import Container from 'react-bootstrap/Container';

import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import Offcanvas from 'react-bootstrap/Offcanvas';
import {Link } from "react-router-dom"

import {useState , useEffect} from 'react';
import axios from "axios";

const Driver=()=>{
 
  const [houses,sethouses]=useState([]);
  const [arr,setarr]=useState([]);
  useEffect(()=>{
    axios.get('http://localhost:5000/getData')
    .then((res)=>{
      for(let i=0;i<res.data.length;i++){
        if(res.data[i].designation==='driver'){
          arr.push(res.data[i]);
        }
      }
      sethouses(arr);
    })
  })




    return(
      <div className="containerFluid">
         <div>
      {['xxl' ].map((expand) => (
        <Navbar key={expand} bg="light" expand={expand} className="mb-3" style={{padding:"0"}}>
          <Container fluid id="portal1">
            <Navbar.Brand href="#"><p id="portal">Driver Attendance Portal</p></Navbar.Brand>
            <Navbar.Toggle aria-controls={`offcanvasNavbar-expand-${expand}`} />
            <Navbar.Offcanvas
              id={`offcanvasNavbar-expand-${expand}`}
              aria-labelledby={`offcanvasNavbarLabel-expand-${expand}`}
              placement="end"
            >
              <Offcanvas.Header closeButton>
                <Offcanvas.Title id={`offcanvasNavbarLabel-expand-${expand}`}>
                  Welcome
                </Offcanvas.Title>
              </Offcanvas.Header>
              <Offcanvas.Body>
                <Nav className="justify-content-end flex-grow-1 pe-3" >
                  {/* <Nav.Link href="#action1"><Link to="login"  className='menu'>Login</Link></Nav.Link> */}
                  
                  <NavDropdown
                    title="Click here"
                    id={`offcanvasNavbarDropdown-expand-${expand}` }
                  >
                    <NavDropdown.Item href="#action3" ><Link to="/dash" className='menu'>Dashboard</Link></NavDropdown.Item>
                    <NavDropdown.Item href="#action3"><Link to="/drinfo" className='menu'>Driver's info</Link></NavDropdown.Item>
                    <NavDropdown.Item href="#action3"><Link to="/crinfo" className='menu'>cleaner's info</Link></NavDropdown.Item>
                    {/* <NavDropdown.Item href="#action3"><Link to="dcmr" className='menu' >Driver's Current Monthly Report</Link></NavDropdown.Item> */}
                    <NavDropdown.Item href="#action3"><Link to='/ccmr' className='menu'>Cleaner's Current Monthly Report</Link></NavDropdown.Item>
                    <NavDropdown.Item href="#action3"><Link to="/dar" className='menu'>Daily Attendance Report</Link></NavDropdown.Item>
                    <NavDropdown.Item href="#action3"><Link to="/mr" className='menu'>Monthly Report</Link></NavDropdown.Item>
                    <NavDropdown.Item href="#action3"><Link to="/form" className='menu'>Form</Link></NavDropdown.Item>
                    
                  </NavDropdown>
                  <Nav.Link href="#action1"><Link to="/" className='menu'>Log Out</Link></Nav.Link>
                </Nav>
              </Offcanvas.Body>
            </Navbar.Offcanvas>
          </Container>
        </Navbar>
      ))}
      </div>
      <div className="row">
             <div className="col-md-12" id="innerhead">
                <div >
                   <p>Drivers Attendance(Apr-2023-Report)Data</p>
                </div>
             </div>
          </div>
          <div className="row" id="buttons1">
            <div className="col-md-6" id="buttons">
              <ul>
                <li><button>Copy</button></li>
                <li><button>Csv</button></li>
                <li><button>Excel</button></li>
                <li><button>PDF</button></li>
                <li><button>Print</button></li>
              </ul>
            </div>
            <div className="col-m d-6" >
              <form id="forms">
                <label>Search: </label>
                <input type="text" id="forms1"></input>
              </form>
            </div>
          </div>
         <div className="row">
          <div className="col-md-12" style={{width:"100%",overflow:"auto"}}>
          <table border={2} className="table table-bordered">
            <thead>
            <tr>
             
              <th>Staff Name</th>
              <th>Biometric Id</th>
             <th>Designation</th>
              <th>Mobile</th>
              <th>Bus Number</th>
              <th>Route Code</th>
              <th>Aadharcard No</th>
              <th>Delete Record</th>
             </tr>
            </thead>

             {
              houses.map((val,key) => {
                return(
                 <tbody>
                    <tr key={key}>
                    
                    <td>{val.fullname}</td>
                    <td>{val.biometricid}</td>
                    <td>{val.designation}</td>
                    <td>{val.mobilenumber}</td>
                    <td>{val.busnumber}</td>
                    <td>{val.routecode}</td>
                    <td>{val.adharnumber}</td>
                    <td><button style={{width:"50px",height:"30px",backgroundcolor:"blue"}}>Delete</button></td>
                   
                 </tr>
                 </tbody>
                )
              })
             }
         </table>
          </div>
         </div>
      
     </div>
)

}
export default Driver;


