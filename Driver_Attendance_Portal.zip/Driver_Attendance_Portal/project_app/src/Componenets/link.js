import React from 'react'

const Link = () => {
  return (
    <div>
      <h1>Uday Kiran</h1>
    </div>
  )
}

export default Link
